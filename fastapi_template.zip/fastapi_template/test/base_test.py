import multiprocessing


class AtomicInteger:
    """
    基于 multiprocessing.Value 实现的【多进程安全】原子整型类
    对标 Java AtomicInteger，提供原子操作方法
    """

    def __init__(self, initial: int = 0):
        """
        初始化原子整数
        :param initial: 初始值，默认 0
        """
        # 'i' = 有符号整型 (int)；默认自带进程锁，保证操作原子性
        self._shared_value: multiprocessing.Value = multiprocessing.Value('i', initial)

    def get(self) -> int:
        """原子获取当前值"""
        with self._shared_value:  # 自动加锁/解锁，保证读取原子性
            return self._shared_value.value

    def set(self, value: int) -> None:
        """原子设置值"""
        with self._shared_value:
            self._shared_value.value = value

    def add(self, delta: int) -> int:
        """
        原子增加指定数值
        :param delta: 增量（正数=加，负数=减）
        :return: 增加后的新值
        """
        with self._shared_value:
            self._shared_value.value += delta
            return self._shared_value.value

    def increment(self) -> int:
        """原子自增 1（返回新值）"""
        return self.add(1)

    def decrement(self) -> int:
        """原子自减 1（返回新值）"""
        return self.add(-1)

    def compare_and_set(self, expect: int, update: int) -> bool:
        """
        原子 CAS (Compare And Set) 核心操作
        :param expect: 预期当前值
        :param update: 要设置的新值
        :return: 成功返回 True，失败返回 False
        """
        with self._shared_value:
            if self._shared_value.value == expect:
                self._shared_value.value = update
                return True
            return False

    def __repr__(self) -> str:
        return f"AtomicInteger(value={self.get()})"




def worker(atomic_int: AtomicInteger, loop_count: int):
    """多进程工作函数：循环自增"""
    for _ in range(loop_count):
        atomic_int.increment()


def test_atomic_int():
    # 初始化原子整数（初始值0）
    atomic = AtomicInteger(0)

    # 并发配置
    PROCESS_NUM = 4        # 进程数
    LOOP_TIMES = 1000    # 每个进程自增次数
    EXPECTED_VALUE = PROCESS_NUM * LOOP_TIMES

    # 创建并启动进程
    process_list = [
        multiprocessing.Process(target=worker, args=(atomic, LOOP_TIMES))
        for _ in range(PROCESS_NUM)
    ]
    for p in process_list:
        p.start()

    # 等待所有进程执行完毕
    for p in process_list:
        p.join()

    # 输出结果
    print(f"最终结果: {atomic.get()}")
    print(f"预期结果: {EXPECTED_VALUE}")
    print(f"原子性验证: {'通过' if atomic.get() == EXPECTED_VALUE else '失败'}")




if __name__ == '__main__':
    test_atomic_int()
