import numpy as np
from pandas import pd

combine_list = []


def init_excel_2list():
    # 读取Excel文件中的数据
    all_sheets_dict = pd.read_excel("test.xlsx", sheet_name="Sheet1", engine="openpyxl")

    for sheet_name, df in all_sheets_dict.items():
        df_filter = df.replace(
            [np.nan, np.inf, -np.inf], [None, "Infinity", "-Infinity"]
        )

        combine_list.extend(df_filter.to_dict(orient="records"))

    print("init db ok...")
