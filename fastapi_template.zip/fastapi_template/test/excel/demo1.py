import polars as pl
from pathlib import Path
import shutil
import yaml
import polars as pl
from pathlib import Path
from typing import List, Dict


def create_test_excels(output_dir: str = "./test_data"):
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)

    # 1. 生成采购模块测试数据
    df_purchase = pl.DataFrame({
        "商品名称": ["笔记本电脑", "机械键盘", "无线鼠标", "显示器", "USB扩展坞"],
        "不含税金额": [4500.00, 320.50, 89.90, 1200.00, 159.00],
        "税率": [0.13, 0.13, 0.13, 0.13, 0.06]
    })
    purchase_file = output_path / "供应商A_采购.xlsx"
    df_purchase.write_excel(purchase_file, worksheet="采购明细")
    print(f"✅ 已生成: {purchase_file.absolute()}")

    # 2. 生成物流模块测试数据
    df_logistics = pl.DataFrame({
        "运单号": ["SF20240601001", "SF20240601002", "SF20240601003", "SF20240601004", "YD20240601005"],
        "起步价": [12.00, 12.00, 15.00, 12.00, 8.00],
        "超重重量": [3.2, 0.0, 7.5, 1.8, 0.0],
        "超重单价": [2.50, 2.50, 3.00, 2.50, 1.50]
    })
    logistics_file = output_path / "供应商B_物流.xlsx"
    df_logistics.write_excel(logistics_file, worksheet="物流配送明细")
    print(f"✅ 已生成: {logistics_file.absolute()}")



# ==========================================
# 1. 配置定义
# ==========================================
RULE_CONFIG_YAML = """
rule_config:
  - module_name: 采购模块
    target_column: 应付税额
    formula: 不含税金额 * 税率
    dependent_columns: ["不含税金额", "税率"]
    decimal: 2
    rounding: "round_half_up"
    applicable_suppliers: ["全部"]
    sheet_keyword: ["采购"]
  - module_name: 物流模块
    target_column: 结算金额
    formula: 起步价 + 超重重量 * 超重单价
    dependent_columns: ["起步价", "超重重量", "超重单价"]
    decimal: 2
    applicable_suppliers: ["供应商A", "供应商B"]
    sheet_keyword: ["物流", "配送"]
"""

# ==========================================
# 2. 修复后的对账引擎
# ==========================================
class ReconciliationEngine:
    def __init__(self, config: Dict, input_dir: str = "./input", output_dir: str = "./output"):
        self.config = config["rule_config"]
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.logs = []

    def _log(self, msg: str, level: str = "INFO"):
        log_msg = f"[{level}] {msg}"
        print(log_msg)
        self.logs.append(log_msg)

    def _generate_test_data(self):
        """生成 Demo 用的测试 Excel 文件"""
        self.input_dir.mkdir(exist_ok=True)
        
        # 1. 采购模块
        df_purchase = pl.DataFrame({
            "商品名称": ["笔记本电脑", "机械键盘", "无线鼠标", "显示器", "USB扩展坞"],
            "不含税金额": [4500.00, 320.50, 89.90, 1200.00, 159.00],
            "税率": [0.13, 0.13, 0.13, 0.13, 0.06]
        })
        purchase_path = self.input_dir / "供应商A_采购.xlsx"
        df_purchase.write_excel(purchase_path, worksheet="采购明细")

        # 2. 物流模块
        df_logistics = pl.DataFrame({
            "运单号": ["SF20240601001", "SF20240601002", "SF20240601003", "SF20240601004", "YD20240601005"],
            "起步价": [12.00, 12.00, 15.00, 12.00, 8.00],
            "超重重量": [3.2, 0.0, 7.5, 1.8, 0.0],
            "超重单价": [2.50, 2.50, 3.00, 2.50, 1.50]
        })
        logistics_path = self.input_dir / "供应商B_物流.xlsx"
        df_logistics.write_excel(logistics_path, worksheet="物流配送明细")

        self._log(f"测试数据已生成至: {self.input_dir.absolute()}")

    def _match_rule(self, sheet_name: str) -> Dict:
        """根据 Sheet 名称匹配对应的规则"""
        for rule in self.config:
            for keyword in rule["sheet_keyword"]:
                if keyword in sheet_name:
                    return rule
        return None

    def _formula_to_polars_expr(self, formula: str, dependent_cols: List[str]) -> pl.Expr:
        """将业务公式安全转换为 Polars 表达式"""
        expr_str = formula
        for col in dependent_cols:
            # 确保列名被正确替换
            expr_str = expr_str.replace(col, f'pl.col("{col}")')
        
        # 安全执行环境
        local_vars = {"pl": pl}
        try:
            return eval(expr_str, {"__builtins__": {}}, local_vars)
        except Exception as e:
            raise ValueError(f"公式解析失败: {formula}, 错误: {e}")

    def _process_file(self, file_path: Path):
        """处理单个 Excel 文件（核心修复：纯 Polars 读写）"""
        self._log(f"正在处理: {file_path.name}")

        # 1. 备份原文件
        backup_path = self.output_dir / f"[备份]{file_path.name}"
        shutil.copy(file_path, backup_path)

        # 2. 读取 Excel 所有 Sheet
        try:
            # 读取为 {Sheet名: DataFrame} 的字典
            excel_data = pl.read_excel(file_path, sheet_id=0)
        except Exception as e:
            self._log(f"读取文件失败: {e}", "ERROR")
            return

        # 3. 遍历处理每个 Sheet
        processed_data = {}
        for sheet_name, df in excel_data.items():
            rule = self._match_rule(sheet_name)
            
            if not rule:
                self._log(f"  - Sheet [{sheet_name}] 未匹配规则，原样保留")
                processed_data[sheet_name] = df
                continue

            # 前置校验
            missing_cols = [c for c in rule["dependent_columns"] if c not in df.columns]
            if missing_cols:
                self._log(f"  - Sheet [{sheet_name}] 缺少列: {missing_cols}，跳过", "ERROR")
                processed_data[sheet_name] = df
                continue

            # 执行计算
            try:
                expr = self._formula_to_polars_expr(rule["formula"], rule["dependent_columns"])
                # 计算并保留两位小数
                df_result = df.with_columns(
                    expr.round(rule["decimal"]).alias(rule["target_column"])
                )
                processed_data[sheet_name] = df_result
                self._log(f"  - Sheet [{sheet_name}] 计算完成 ({rule['module_name']})")
            except Exception as e:
                self._log(f"  - Sheet [{sheet_name}] 计算异常: {e}", "ERROR")
                processed_data[sheet_name] = df

        # 4. 写回 Excel (兼容旧版本 Polars 的写法)
        output_path = self.output_dir / file_path.name
        
        # 先写入第一个 Sheet 以创建文件
        sheet_names = list(processed_data.keys())
        first_sheet = sheet_names[0]
        processed_data[first_sheet].write_excel(output_path, worksheet=first_sheet)
        
        # 追加写入剩余的 Sheet
        if len(sheet_names) > 1:
            for sheet_name in sheet_names[1:]:
                processed_data[sheet_name].write_excel(
                    output_path, 
                    worksheet=sheet_name,
                    mode="a"  # 追加模式
                )

        self._log(f"  - 结果已保存: {output_path.name}\n")


    def run(self, generate_test_data: bool = True):
        if generate_test_data:
            self._generate_test_data()

        if not self.input_dir.exists():
            self._log("输入文件夹不存在", "ERROR")
            return

        excel_files = list(self.input_dir.glob("*.xlsx"))
        if not excel_files:
            self._log("未找到 Excel 文件", "WARN")
            return

        for file_path in excel_files:
            self._process_file(file_path)

        self._log("="*30)
        self._log("所有文件处理完毕")


# polars==1.38.1
# fastexcel==0.19.0
# xlsxwriter==3.2.9
# pip list | grep "fastexcel"
# https://www.doubao.com/chat/38416401387794178
# https://zhuanlan.zhihu.com/p/683461941
if __name__ == "__main__":
    # create_test_excels()

    # 加载配置
    config = yaml.safe_load(RULE_CONFIG_YAML)
    
    # 初始化引擎并运行
    engine = ReconciliationEngine(config=config)
    engine.run(generate_test_data=False)

