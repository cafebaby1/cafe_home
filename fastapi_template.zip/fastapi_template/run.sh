#!/bin/bash

APP="main:app"
HOST="0.0.0.0"
# PORT=8001
# PYTHON=$(which python3)
PID_FILE="app.pid"
LOG_FILE="server.log"

CONDA_BASE=$(conda info --base)
source $CONDA_BASE/etc/profile.d/conda.sh

cd ./app

start_app() {
    if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
        echo "❗ Server already running (PID: $(cat $PID_FILE))"
        exit 1
    fi

    echo "🚀 Starting server..."
    # nohup $PYTHON -m uvicorn $APP --host $HOST --port $PORT >> $LOG_FILE 2>&1 &
    conda activate mcp_agent
    nohup python main.py >> $LOG_FILE 2>&1 &
    echo $! > $PID_FILE
    echo "✔ Started. PID: $(cat $PID_FILE)"
}

stop_app() {
    
    
    if [ ! -f "$PID_FILE" ]; then
        echo "❗ PID file not found. Server may not be running."
        exit 1
    fi

    PID=$(cat $PID_FILE)
    if kill -0 $PID 2>/dev/null; then
        echo "🛑 Stopping server (PID: $PID)…"
        kill $PID
        rm -f $PID_FILE
        echo "✔ Stopped."
    else
        echo "❗ Server process not running but PID file exists. Cleaning up..."
        rm -f $PID_FILE
    fi
}

restart_app() {
    echo "🔄 Restarting server..."
    stop_app
    sleep 1
    start_app
}

case "$1" in
    start)
        start_app
        ;;
    stop)
        stop_app
        ;;
    restart)
        restart_app
        ;;
    *)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
        ;;
esac
