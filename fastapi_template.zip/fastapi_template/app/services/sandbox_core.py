import json
import os
import subprocess
import sys
import tempfile
import uuid
import logging
from pathlib import Path
from textwrap import dedent
from typing import Dict, Any, Optional

logger = logging.getLogger()


class SandboxConfig:
    """沙箱配置类"""

    def __init__(
        self,
        sandbox_home: Optional[str] = None,
        banned_keywords: str = "",
        banned_hosts: str = "",
    ):
        self.sandbox_home = sandbox_home or os.path.join(Path.home(), "sandbox")
        self.banned_keywords = [k.strip() for k in banned_keywords.split(",") if k.strip()]
        self.banned_hosts = [h.strip() for h in banned_hosts.split(",") if h.strip()]

        # 初始化沙箱目录
        self._init_sandbox_dir()

    def _init_sandbox_dir(self):
        """初始化沙箱目录结构"""
        sandbox_path = Path(self.sandbox_home)

        # 创建必要的子目录
        for subdir in ["execute", "result", "temp"]:
            dir_path = sandbox_path / subdir
            dir_path.mkdir(parents=True, exist_ok=True, mode=0o700)
            logger.info(f"Created sandbox directory: {dir_path}")


class ToolExecutor:
    """Python 代码沙箱执行器"""

    def __init__(self, config: SandboxConfig = None, use_temp_dir: bool = True, python_executable: Optional[str] = None):
        """
        初始化沙箱执行器

        Args:
            config: 沙箱配置对象
            use_temp_dir: 是否使用临时目录（每次执行创建新的工作目录）
            python_executable: python binary to run (defaults to current interpreter)
        """
        self.config = config or SandboxConfig()
        self.use_temp_dir = use_temp_dir
        self.python_exec = python_executable or sys.executable
        self.sandbox_path = Path(self.config.sandbox_home)

    def _validate_banned_keywords(self, code_str: str) -> None:
        """检查代码是否包含被禁止的关键字"""
        for keyword in self.config.banned_keywords:
            if keyword and keyword in code_str:
                raise ValueError(f"Code contains banned keyword: '{keyword}'")

    def _create_execution_wrapper(
        self, code_str: str, keywords: Dict[str, Any], result_file: str
    ) -> str:
        """
        创建包装着执行用户代码的 Python 脚本（写给 subprocess -c 执行）
        使用单一 globals_v 环境确保 import 可见。
        """
        wrapper_code = f"""
import json
import sys
import traceback

try:
    globals_v = {{}}
    keywords = {json.dumps(keywords)}
    exec({repr(dedent(code_str))}, globals_v)
    callables = [(k, v) for k, v in globals_v.items() if callable(v) and not k.startswith('_')]
    f_name, f = callables[-1] if callables else (None, None)
    if f is not None and callable(f):
        exec_result = f(**keywords)
    else:
        exec_result = None
        if 'result' in globals_v:
            exec_result = globals_v['result']

    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'code': 200,
            'msg': 'Success',
            'data': exec_result
        }}, file, default=str)
except Exception as e:
    import traceback
    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'code': 500,
            'msg': str(e),
            'traceback': traceback.format_exc(),
            'data': None
        }}, file, default=str)
"""
        return wrapper_code

    def exec_code(self, code_str: str, keywords: Dict[str, Any] = None, timeout: int = 30) -> Dict[str, Any]:
        """
        同步执行 code_str 并返回一个 dict 结果，包含 code/msg/data/traceback（若有）
        抛出 ValueError 如果包含被禁止关键字，抛出 RuntimeError 如果执行出错（subprocess returncode != 0 或者 result file 不存在）
        """
        keywords = keywords or {}
        self._validate_banned_keywords(code_str)

        exec_id = str(uuid.uuid4())

        if self.use_temp_dir:
            temp_dir = tempfile.mkdtemp(prefix="sandbox_", dir=os.path.join(self.config.sandbox_home, "temp"))
            work_dir = temp_dir
            result_file = os.path.join(temp_dir, f"{exec_id}.result")
        else:
            work_dir = os.path.join(self.config.sandbox_home, "execute")
            result_file = os.path.join(self.config.sandbox_home, "result", f"{exec_id}.result")
            os.makedirs(work_dir, exist_ok=True)

        wrapper_code = self._create_execution_wrapper(code_str, keywords, result_file)

        logger.info(f"[ToolExecutor] Executing code id={exec_id} cwd={work_dir}")
        # Run wrapper in subprocess
        result = subprocess.run(
            [self.python_exec, "-c", wrapper_code],
            capture_output=True,
            text=True,
            cwd=work_dir,
            timeout=timeout,
        )

        # If subprocess itself failed, return structured error
        if result.returncode != 0:
            logger.error(f"Subprocess returncode={result.returncode}. stderr: {result.stderr}")
            # try to read result_file anyway if present
            if os.path.exists(result_file):
                with open(result_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            raise RuntimeError(f"Code execution failed: {result.stderr}")

        if not os.path.exists(result_file):
            raise RuntimeError("Result file not created by wrapper")

        with open(result_file, "r", encoding="utf-8") as f:
            result_data = json.load(f)

        # optionally cleanup temp_dir if using temp
        # (we leave files for debugging; caller can call cleanup if needed)
        return result_data

    def cleanup(self):
        """删除整个 sandbox 目录（危险操作，用于测试）"""
        import shutil
        if self.sandbox_path.exists():
            shutil.rmtree(self.sandbox_path)
            logger.info(f"Cleaned up sandbox: {self.sandbox_path}")
