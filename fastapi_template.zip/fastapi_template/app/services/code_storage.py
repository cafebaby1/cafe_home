from typing import Dict, Optional, List
from datetime import datetime
import uuid

# simple in-memory storage
# code items stored as dict:
# { id: {id, name, code, created_at, updated_at} }
_STORE: Dict[str, Dict] = {}


def list_codes() -> List[Dict]:
    return list(_STORE.values())


def create_code(name: str, code: str) -> Dict:
    now = datetime.utcnow().isoformat() + "Z"
    _id = str(uuid.uuid4())
    item = {"id": _id, "name": name, "code": code, "created_at": now, "updated_at": now}
    _STORE[_id] = item
    return item


def get_code(_id: str) -> Optional[Dict]:
    return _STORE.get(_id)


def update_code(_id: str, name: str = None, code: str = None) -> Optional[Dict]:
    item = _STORE.get(_id)
    if not item:
        return None
    changed = False
    if name is not None:
        item["name"] = name
        changed = True
    if code is not None:
        item["code"] = code
        changed = True
    if changed:
        from datetime import datetime
        item["updated_at"] = datetime.utcnow().isoformat() + "Z"
    _STORE[_id] = item
    return item


def delete_code(_id: str) -> bool:
    if _id in _STORE:
        del _STORE[_id]
        return True
    return False
