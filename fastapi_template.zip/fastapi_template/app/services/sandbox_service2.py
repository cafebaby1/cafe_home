import ast
import json
import logging
import os
import subprocess
from textwrap import dedent
import platform
import resource

from core.tools import get_code_forbidden

# https://www.bilibili.com/video/BV1x5phe5EA5
# https://chatgpt.com/c/69255bc4-60e4-8323-ad78-bdb7901bd7ff
# https://chatgpt.com/c/69251d14-37b0-8324-9a6a-014c62031315


logger = logging.getLogger()
work_dir = os.path.join("output", "sandbox")



def should_use_limit_resources() -> bool:
    """
    判断是否应该使用 preexec_fn=limit_resources。
    Windows 不支持 preexec_fn，因此自动禁用。
    """
    system = platform.system().lower()
    return system in ["linux", "darwin"]  # Darwin = macOS




def limit_resources():
    """
    在子进程中执行，用于限制用户代码的资源。
    仅 Unix 系统有效。
    """
    try:
        # 限制 CPU 时间：1 秒，超时自动 SIGXCPU
        resource.setrlimit(resource.RLIMIT_CPU, (1, 1))

        # 导致运行报错
        # 限制最大内存：256MB
        # memory_limit = 256 * 1024 * 1024
        # resource.setrlimit(resource.RLIMIT_AS, (memory_limit, memory_limit))

        # # 限制最多写入 5MB 文件
        resource.setrlimit(resource.RLIMIT_FSIZE, (5 * 1024 * 1024, 10 * 1024 * 1024))

        # 禁止 fork 新进程
        resource.setrlimit(resource.RLIMIT_NPROC, (1, 1))

        # # 限制文件句柄数量
        resource.setrlimit(resource.RLIMIT_NOFILE, (16, 16))

        # # 禁止 core dump
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except Exception as e:
        # 只能写入 os.write，不要用 print 或 logging！
        # import os
        # os.write(2, f"[preexec_fn error] {repr(e)}\n".encode())
        # raise
        pass


# 定义不允许的导入和关键词
forbidden_imports = [
    "impostlib",
    "os",
    "sys",
    "commands",
    "subprocess",
    "socket",
    "threading",
    "multiprocessing",
    "pickle",
    "marshal",
    "shelve",
]

forbidden_keywords = ["exec", "eval", "open", "input", "__import__"]


def extend_forbidden_keywords():
    forbidden_imports_arr, forbidden_keywords_arr = get_code_forbidden()

    if len(forbidden_imports_arr) > 0:
        forbidden_imports.extend(forbidden_imports_arr)
    print(f"导入白名单更新: {forbidden_imports}")

    if len(forbidden_keywords_arr) > 0:
        forbidden_keywords.extend(forbidden_keywords_arr)
    print(f"关键字白名单更新: {forbidden_keywords}")


extend_forbidden_keywords()


def check_code_safety(code):
    """使用AST模块检查代码安全性"""
    try:
        tree = ast.parse(code)
    except Exception:
        raise ValueError("Python语法无效。")

    for node in ast.walk(tree):
        if isinstance(node, ast.Import) or isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name in forbidden_imports:
                    raise ValueError(f"检测到禁止的模块: {alias.name}")

        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in forbidden_keywords:
                raise ValueError(f"检测到禁止的关键字: {node.func.id}")


class InfiniteLoopDetector(ast.NodeVisitor):
    """简单的死循环检测器"""

    def __init__(self):
        self.has_infinite_while_true = False
        self.has_for_without_break = False

    def visit_While(self, node: ast.While):
        # 检查 "while True" / "while 1"
        if isinstance(node.test, ast.Constant) and node.test.value in (True, 1):
            self.has_infinite_while_true = True

        # 检查是否不存在 break
        if not any(isinstance(n, ast.Break) for n in ast.walk(node)):
            # 如果条件不可变（简单判断）
            if isinstance(node.test, ast.Name):
                # 循环变量从未被修改
                if not any(
                    isinstance(n, ast.Assign) and n.targets[0].id == node.test.id
                    for n in ast.walk(node)
                ):
                    self.has_infinite_while_true = True

        self.generic_visit(node)

    def visit_For(self, node: ast.For):
        # for 循环没有 break 且 iter 不可变
        has_break = any(isinstance(n, ast.Break) for n in ast.walk(node))
        if not has_break:
            # 粗略判定为风险循环
            self.has_for_without_break = True
        self.generic_visit(node)


def detect_potential_infinite_loop(code_str: str) -> bool:
    try:
        tree = ast.parse(code_str)
    except SyntaxError as e:
        logger.exception(e)
        raise ValueError("Python语法无效")

    detector = InfiniteLoopDetector()
    detector.visit(tree)

    result = detector.has_infinite_while_true or detector.has_for_without_break
    logger.info(f"Potential infinite loop detected: {result}")

    if result is True:
        raise ValueError("代码中有死循环")

    return result


def run_in_sandbox(code: str):
    try:
        # result = subprocess.run(
        #     ["python", "-c", code],
        #     stdout=subprocess.PIPE,
        #     stderr=subprocess.PIPE,
        #     check=True,
        # )
        # return result.stdout.decode(), result.stderr.decode()

        result = subprocess.run(
            ["python", "-c", code],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            # 自动 decode
            text=True,
            timeout=1,
        )

        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        raise ValueError(f"run code in sandbox error: {str(e)}")


def exec_code(code: str, params: dict[str, any], exec_id: str):
    result_file = os.path.join(work_dir, f"{exec_id}_result.txt")

    try:
        wrapper_code = _create_execution_wrapper(code, params, result_file)
        logger.info(f"Executing code with ID: {exec_id}")

        # 根据操作系统决定是否加入 preexec_fn
        preexec_fn_value = limit_resources if should_use_limit_resources() else None

        result = subprocess.run(
            ["python", "-c", wrapper_code],
            capture_output=True,
            text=True,
            timeout=1.0,
            preexec_fn=preexec_fn_value,
        )
        # logger.info(f"Execution result: {result}")

        if result.returncode != 0:
            logger.error(f"Execution error: {result.stderr}")
            raise ValueError(f"{result.stderr}")

        
        # 读取结果文件
        if not os.path.exists(result_file):
            raise ValueError("Result file not created")


        exe_result = None
        with open(result_file, "r", encoding="utf-8") as f:
            result_data = json.load(f)
            
            if result_data.get("result") is True:
                exe_result = result_data.get("data")
            else:
                error_msg = result_data.get("msg", "Unknown error")
                logger.error(f"Execution error for ID {exec_id}: {error_msg}")
                raise ValueError(f"{error_msg}")

        return result.stdout, result.stderr, result.returncode, exe_result
    except Exception as e:
        raise e



def _create_execution_wrapper(
    code_str: str, keywords: dict[str, any], result_file: str
) -> str:
    """
    创建代码执行包装器

    只使用 globals_v，确保 import 的模块在函数执行时可见

    Args:
        code_str: 用户代码
        keywords: 传递给函数的关键字参数
        result_file: 结果文件路径

    Returns:
        包装后的执行代码
    """
    wrapper_code = f"""
import json
import sys
import traceback

try:
    # 修复点：只使用一个全局环境，确保 import 语句对函数可见
    globals_v = {{}}
    keywords = {json.dumps(keywords)}
    code_raw = {json.dumps(code_str)}

    # 执行用户代码（包括 import 语句和函数定义）
    # import 语句会加到 globals_v 中
    exec({repr(dedent(code_str))}, globals_v)

    # 从全局环境中找到所有 callable 对象（函数）
    # 通常是代码中定义的最后一个函数
    callables = [(k, v) for k, v in globals_v.items() if callable(v) and not k.startswith('_')]

    f_name, f = callables[-1] if callables else (None, None)

    if f is not None and callable(f):
        # 关键：函数执行时使用相同的 globals_v，包含所有 import 的模块
        # 这样函数内部的 math, json, os 等导入才可见
        exec_result = f(**keywords)
    else:
        # 如果没有找到函数，尝试直接返回执行结果
        exec_result = None
        if 'result' in globals_v:
            exec_result = globals_v['result']

    # 保存结果
    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'result': True,
            'code': code_raw,
            'params': keywords,
            'data': exec_result
        }}, file, default=str, indent=4)
        
except Exception as e:
    import traceback
    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'result': False,
            'code': code_raw,
            'params': keywords,
            'data': None,
            'msg': traceback.format_exc(),
        }}, file, default=str, indent=4)
    
    raise e
"""

    return wrapper_code





# timeout=1.0 限制的是 墙钟时间（wall-clock time）
# 包括 I/O 等待
# 包括 sleep
# 即你按手机计时器看到的那种时间


# RLIMIT_CPU 限制的是 CPU 占用时间（CPU time）
# 不包括 sleep
# 不包括 I/O 等待
# 只有执行真正的 CPU 指令才计时
# 效果：
# 用户代码在 1 秒 CPU 时间内跑满 100% → 被 OS 发 SIGXCPU 终止
