import ast
import json
import logging
import os
import subprocess
from textwrap import dedent

from core.tools import get_code_forbidden


logger = logging.getLogger()
work_dir = os.path.join("output", "sandbox")


# 定义不允许的导入和关键词
forbidden_imports = [
    "impostlib",
    "os",
    "sys",
    "commands",
    "subprocess",
    # "socket",
    "threading",
    "multiprocessing",
    "pickle",
    "marshal",
    "shelve",
]

forbidden_keywords = ["exec", "eval", "open", "input", "__import__"]


def extend_forbidden_keywords():
    forbidden_imports_arr, forbidden_keywords_arr = get_code_forbidden()

    if len(forbidden_imports_arr) > 0:
        forbidden_imports.extend(forbidden_imports_arr)
    print(f"导入白名单更新: {forbidden_imports}")

    if len(forbidden_keywords_arr) > 0:
        forbidden_keywords.extend(forbidden_keywords_arr)
    print(f"关键字白名单更新: {forbidden_keywords}")


extend_forbidden_keywords()


def check_code_safety(code):
    """使用AST模块检查代码安全性"""
    try:
        tree = ast.parse(code)
    except Exception:
        raise ValueError("Python语法无效。")

    for node in ast.walk(tree):
        if isinstance(node, ast.Import) or isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name in forbidden_imports:
                    raise ValueError(f"检测到禁止的模块: {alias.name}")

        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in forbidden_keywords:
                raise ValueError(f"检测到禁止的关键字: {node.func.id}")



def run_in_sandbox(code: str):
    try:
        result = subprocess.run(
            ["python", "-c", code],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
            # 自动 decode
            text=True,
            timeout=1,
        )

        return result.stdout, result.stderr, result.returncode
    except Exception as e:
        raise ValueError(f"run code in sandbox error: {str(e)}")


def exec_code(code: str, params: dict[str, any], exec_id: str):
    result_file = os.path.join(work_dir, f"{exec_id}_result.txt")

    try:
        wrapper_code = _create_execution_wrapper(code, params, result_file)
        logger.info(f"Executing code with ID: {exec_id}")

        result = subprocess.run(
            ["python", "-c", wrapper_code],
            capture_output=True,
            text=True,
            timeout=15.0,
        )

        if result.returncode != 0:
            logger.error(f"Execution error: {result.stderr}")
            raise ValueError(f"{result.stderr}")

        
        # 读取结果文件
        if not os.path.exists(result_file):
            raise ValueError("Result file not created")


        exe_result = None
        with open(result_file, "r", encoding="utf-8") as f:
            result_data = json.load(f)
            
            if result_data.get("result") is True:
                exe_result = result_data.get("data")
            else:
                error_msg = result_data.get("msg", "Unknown error")
                logger.error(f"Execution error for ID {exec_id}: {error_msg}")
                raise ValueError(f"{error_msg}")

        return result.stdout, result.stderr, result.returncode, exe_result
    except Exception as e:
        raise e



def _create_execution_wrapper(
    code_str: str, keywords: dict[str, any], result_file: str
) -> str:
    """
    创建代码执行包装器

    只使用 globals_v，确保 import 的模块在函数执行时可见

    Args:
        code_str: 用户代码
        keywords: 传递给函数的关键字参数
        result_file: 结果文件路径

    Returns:
        包装后的执行代码
    """
    wrapper_code = f"""
import json
import sys
import traceback

try:
    # 修复点：只使用一个全局环境，确保 import 语句对函数可见
    globals_v = {{}}
    # code_raw = {json.dumps(code_str)}
    # keywords = {json.dumps(keywords)}
    
    code_raw = {repr(code_str)}

    # 使用repr序列化keywords（JSON null→Python None），而非json.dumps
    keywords = {repr(keywords)}

    # 执行用户代码（包括 import 语句和函数定义）
    # import 语句会加到 globals_v 中
    exec({repr(dedent(code_str))}, globals_v)

    # 从全局环境中找到所有 callable 对象（函数）
    # 通常是代码中定义的最后一个函数
    callables = [(k, v) for k, v in globals_v.items() if callable(v) and not k.startswith('_')]

    f_name, f = callables[-1] if callables else (None, None)

    if f is not None and callable(f):
        # 关键：函数执行时使用相同的 globals_v，包含所有 import 的模块
        # 这样函数内部的 math, json, os 等导入才可见
        exec_result = f(**keywords)
    else:
        # 如果没有找到函数，尝试直接返回执行结果
        exec_result = None
        if 'result' in globals_v:
            exec_result = globals_v['result']

    # 保存结果
    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'result': True,
            'code': code_raw,
            'params': keywords,
            'data': exec_result
        }}, file, default=str, indent=4)
        
except Exception as e:
    import traceback
    with open({repr(result_file)}, 'w', encoding='utf-8') as file:
        json.dump({{
            'result': False,
            'code': code_raw,
            'params': keywords,
            'data': None,
            'msg': traceback.format_exc(),
        }}, file, default=str, indent=4)
    
    raise e
"""

    return wrapper_code
