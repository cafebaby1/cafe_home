import base64
from concurrent.futures import CancelledError, ThreadPoolExecutor
import logging
from subprocess import TimeoutExpired
from langchain_sandbox import PyodideSandbox

from fastapi import APIRouter

from services.sandbox_service import check_code_safety, run_in_sandbox, exec_code
from dto.requests import ExecuteCodeRequest, RunCodeRequest
from utils.tools import get_uuid, resp_ok, resp_error


logger = logging.getLogger(__name__)

# 创建API路由
_ROUTE = "sandbox"

router = APIRouter(prefix=f"/{_ROUTE}", tags=[_ROUTE])



# Create a sandbox instance
sandbox = PyodideSandbox(
    # Allow Pyodide to install python packages that
    # might be required.
    allow_net=False,
)


@router.post("/run")
async def run(request: ExecuteCodeRequest):
    logger.info(f"run2 code: {request.json_str()}")

    try:
        code = request.content
        check_code_safety(code)

        # Execute Python code
        result = await sandbox.execute(code)
        return resp_ok(result)
    except Exception as e:
        logger.error(f"sandbox execute error: {e}")
        return resp_error(str(e))


executor = ThreadPoolExecutor(max_workers=10)

@router.post("/run2")
async def run2(request: RunCodeRequest):
    logger.info(f"run2 code: {request.json_str()}")

    try:
        code = request.content
        check_code_safety(code)

        future = executor.submit(run_in_sandbox, code)
        try:
            # 设置超时时间
            output, errors, code = future.result(timeout=1.0)
            logging.info(f"code run2 errors: {errors}")

            return resp_ok(
                {
                    "stdout": output,
                    "stderr": errors,
                    "code": code,
                }
            )
        except TimeoutError:
            raise ValueError("运行时间超出限制")
        except CancelledError:
            raise ValueError("任务取消")
        except Exception as e:
            raise e
    
    except Exception as e:
        logger.error(f"sandbox execute error: {str(e)}")
        return resp_error("sandbox execute error")




@router.post("/exec_code")
async def exec_code_router(request: ExecuteCodeRequest):
    logger.info(f"exec_code code: {request.json_str()}")

    try:
        code = request.code
        rid = request.request_id
        params = request.params
        if params is None:
            params = {}
        
        check_code_safety(code)
        # detect_potential_infinite_loop(code)

        try:
            output, errors, return_code, exe_result = exec_code(code, params, rid)

            return resp_ok(
                {
                    "stdout": output,
                    "stderr": errors,
                    "code": return_code,
                    "result": exe_result,
                }
            )
        except TimeoutExpired:
            raise ValueError("运行时间超出限制")
        except TimeoutError:
            raise ValueError("运行时间超出限制")
        except CancelledError:
            raise ValueError("任务取消")
        except Exception as e:
            raise e
    
    except Exception as e:
        logger.exception(e)
        return resp_error(f"sandbox execute error: {str(e)}")



def base64_to_str(base64_str: str) -> str:
    # 解码得到二进制数据
    decoded_data = base64.b64decode(base64_str)

    # 将二进制数据转换为字符串
    decoded_data_str = decoded_data.decode("utf-8")
    return decoded_data_str
