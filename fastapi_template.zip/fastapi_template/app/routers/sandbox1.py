# import asyncio
# from fastapi import APIRouter, HTTPException, status
# from fastapi.responses import JSONResponse
# from typing import List
# from services.sandbox_core import SandboxConfig, ToolExecutor
# from utils.kits import root_logger
# from dao import code_storage as storage
# from pojo.models import CodeItem, CodeCreate, CodeUpdate
# from pojo.requests import  ExecRequest, ExecResult



# sandbox_router = APIRouter()

# # Configure sandbox config and executor
# sandbox_config = SandboxConfig(
#     sandbox_home="./sandbox_data",  # local folder for demo
#     banned_keywords="exec,eval,__import__",  # same as your example
# )
# executor = ToolExecutor(config=sandbox_config, use_temp_dir=True)


# @sandbox_router.get("/codes", response_model=List[CodeItem])
# async def list_codes():
#     return storage.list_codes()


# @sandbox_router.post("/codes", response_model=CodeItem, status_code=status.HTTP_201_CREATED)
# async def create_code(item: CodeCreate):
#     created = storage.create_code(name=item.name, code=item.code)
#     return created


# @sandbox_router.get("/codes/{code_id}", response_model=CodeItem)
# async def get_code(code_id: str):
#     itm = storage.get_code(code_id)
#     if not itm:
#         raise HTTPException(status_code=404, detail="Code not found")
#     return itm


# @sandbox_router.put("/codes/{code_id}", response_model=CodeItem)
# async def put_code(code_id: str, item: CodeCreate):
#     # replace entire record (name+code)
#     updated = storage.update_code(code_id, name=item.name, code=item.code)
#     if not updated:
#         raise HTTPException(status_code=404, detail="Code not found")
#     return updated


# @sandbox_router.patch("/codes/{code_id}", response_model=CodeItem)
# async def patch_code(code_id: str, item: CodeUpdate):
#     updated = storage.update_code(code_id, name=item.name, code=item.code)
#     if not updated:
#         raise HTTPException(status_code=404, detail="Code not found")
#     return updated


# @sandbox_router.delete("/codes/{code_id}", status_code=status.HTTP_204_NO_CONTENT)
# async def delete_code(code_id: str):
#     ok = storage.delete_code(code_id)
#     if not ok:
#         raise HTTPException(status_code=404, detail="Code not found")
#     return JSONResponse(status_code=status.HTTP_204_NO_CONTENT, content=None)


# @sandbox_router.post("/codes/{code_id}/run", response_model=ExecResult)
# async def run_code(code_id: str, req: ExecRequest):
#     itm = storage.get_code(code_id)
#     if not itm:
#         raise HTTPException(status_code=404, detail="Code not found")

#     code_str = itm["code"]

#     # execute in thread to avoid blocking event loop
#     try:
#         result = await asyncio.to_thread(executor.exec_code, code_str, req.kwargs or {}, req.timeout)
#     except ValueError as e:
#         # banned keyword detected
#         raise HTTPException(status_code=400, detail=str(e))
#     except RuntimeError as e:
#         raise HTTPException(status_code=500, detail=str(e))
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")

#     # result is expected to be dict with keys 'code', 'msg', 'data', maybe 'traceback'
#     return ExecResult(**result)
