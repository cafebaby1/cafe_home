import asyncio
import json
import logging
from typing import AsyncGenerator
from fastapi import APIRouter, Response
from fastapi.responses import StreamingResponse
from utils.tools import get_uuid, resp_ok, resp_error
from core import tools

# 创建API路由
_ROUTE = "test"

router = APIRouter(prefix=f"/{_ROUTE}", tags=[_ROUTE])


# 异步生成器可以由泛型类型 AsyncGenerator[YieldType, SendType] 
# 生成器，模拟数据流
async def stream_data() -> AsyncGenerator[bytes, None]:
# async def stream_data() -> Generator[bytes, None]:
    for i in range(10):
        await asyncio.sleep(1)  # Simulate some delay
        message = {
            "id": get_uuid(),
            "data": f"Data chunk {i}",
        }
        json_str = "data: " + json.dumps(message) + "\n\n"
        yield json_str.encode("utf-8")


@router.get("/stream")
async def stream(response: Response):
    # response.headers["Content-Type"] = "text/plain"
    return StreamingResponse(stream_data(), media_type="text/event-stream")


@router.get("/setting")
async def setting():
    try:
        return resp_ok(
            tools.get_settings()
        )
    except Exception as e:
        logging.error(f"setting error: {e}")