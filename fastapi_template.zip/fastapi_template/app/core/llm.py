import json
from enum import Enum
from typing import Generator

import requests
from pydantic import BaseModel


class LLMError(Exception):
    pass


class LLMRequestError(LLMError):
    pass


class LLMParseError(LLMError):
    pass


class Role(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class Message(BaseModel):
    role: Role
    content: str

    def model_dump(self, *args, **kwargs):
        d = super().model_dump(*args, **kwargs)
        d["role"] = d["role"].value
        return d


class LLM:
    def __init__(
        self,
        url: str,
        path: str,
        model: str,
        api_key: str,
    ):
        self.url = f"{url}{path}"
        self.model = model
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            # "Host": host,
        }

    def get_stream_response(
        self,
        messages: list[Message],
        temperature: float = 0.1,
        top_p: float = 0.7,
        max_tokens: int = 1024,
        timeout: float = 5.0,
    ) -> Generator:
        stream = True
        _messages = [each.model_dump() for each in messages]

        payload = {
            "model": self.model,
            "messages": _messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
            "stream": stream,
        }

        with requests.post(
            url=self.url,
            json=payload,
            headers=self.headers,
            timeout=timeout,
            stream=stream,
            verify=False,
        ) as response:
            try:
                response.raise_for_status()
            except requests.exceptions.HTTPError as e:
                raise LLMRequestError(response.text) from e

            lines = response.iter_lines()
            for line in lines:
                if line:
                    yield line.decode("utf-8")

    def get_response(
        self,
        messages: list[Message],
        temperature: float = 0.1,
        top_p: float = 0.7,
        max_tokens: int = 1024,
        timeout: float = 300.0,
    ) -> dict:
        stream = False
        _messages = [each.model_dump() for each in messages]

        payload = {
            "model": self.model,
            "messages": _messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
            "stream": stream,
        }

        with requests.post(
            url=self.url,
            json=payload,
            headers=self.headers,
            timeout=timeout,
            stream=stream,
            verify=False,
        ) as response:
            try:
                response.raise_for_status()
            except requests.exceptions.HTTPError as e:
                raise LLMRequestError(response.text) from e

            return response.json()

    @staticmethod
    def parse_stream_response(response: str) -> str:
        try:
            data = response.split(":", 1)[1].strip()
            if data == "[DONE]":
                result = "\n"
            else:
                result = json.loads(data)["choices"][0]["delta"]["content"]
        except Exception as e:
            raise LLMParseError(f"Stream response: {response}") from e
        return result

    @staticmethod
    def parse_response(response: dict) -> str:
        try:
            result = response["choices"][0]["message"]["content"]
        except Exception as e:
            raise LLMParseError(f"Response: {response}") from e
        return result



class CommonLLM:
    # def __init__(
    #     self, model: str, api_key: str, deploy_env: str, timeout: float = 300.0
    # ):
    #     if "uat" in deploy_env:
    #         host = "10.184.136.35:4911"
    #     elif "prod" in deploy_env:
    #         host = "10.184.131.187:5187"
    #     else:
    #         host = "ark.cn-beijing.volces.com"

    #     self.url = f"https://{host}/api/v3/chat/completions"
    #     self.model = model
    #     self.headers = {
    #         "Content-Type": "application/json",
    #         "Authorization": f"Bearer {api_key}",
    #     }
    #     self.timeout = timeout


    def get_response(
        self,
        url: str,
        api_key: str,
        model_name: str,
        messages: list[dict],
        temperature: float = 0.1,
        top_p: float = 0.7,
        max_tokens: int = 1024,
    ) -> dict:
        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
            "stream": False,
        }
        response = requests.post(
            url,
            json=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            timeout=300.0,
            stream=False,
            verify=False,
        )
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            raise RuntimeError(
                f"VolcengineGLM Post request error: {response.text}"
            ) from e
        return response.json()

    @staticmethod
    def parse_response(self, response: dict) -> str:
        return response["choices"][0]["message"]["content"]
