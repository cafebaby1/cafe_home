
class TaskError(Exception):
    pass
