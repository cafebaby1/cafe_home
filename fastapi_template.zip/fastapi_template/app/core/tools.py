import logging
import logging.config
import os
from functools import lru_cache, wraps

from core.errors import TaskError
from core.llm import LLM
from core.settings import Settings


# logging.config.fileConfig(os.path.join("confs", "logger.conf"))


@lru_cache
def get_settings():
    settings = Settings()

    if "uat" in settings.deploy_env:
        settings = Settings(
            _env_file=os.path.join("confs/envs", ".env.uat"),
            _env_file_encoding="utf-8",
        )
    elif "prod" in settings.deploy_env:
        settings = Settings(
            _env_file=os.path.join("confs/envs", ".env.prod"),
            _env_file_encoding="utf-8",
        )
    return settings



@lru_cache
def get_llm_model() -> LLM:
    settings = get_settings()
    return LLM(
        settings.llm_host,
        settings.llm_path,
        settings.llm_model,
        settings.llm_api_key,
    )


@lru_cache
def get_prompts() -> dict[str, str]:
    prompts = {}
    directory = os.path.join("confs", "prompts")
    for root, _, files in os.walk(directory):
        for file in files:
            filepath = os.path.join(root, file)
            with open(filepath, "rt", encoding="utf-8") as f:
                prompts[file] = f.read()
    return prompts


@lru_cache
def get_code_forbidden() -> tuple[list[str], list[str]]:
    settings = get_settings()
    forbidden_imports_arr = settings.forbidden_imports_arr
    forbidden_keywords_arr = settings.forbidden_keywords_arr

    return forbidden_imports_arr, forbidden_keywords_arr


def handle_exceptions(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        logger = logging.getLogger(func.__module__)
        try:
            result = func(*args, **kwargs)
        except Exception as e:
            logger.warning(f"Failed to {func.__name__}: {e}")
            raise TaskError(f"Failed to {func.__name__}")
        else:
            logger.info(f"Successfully {func.__name__}")
        return result

    return wrapper
