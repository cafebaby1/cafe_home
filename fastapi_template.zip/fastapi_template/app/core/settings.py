import os

from pydantic_settings import BaseSettings, SettingsConfigDict

from utils.tools import str_not_blank


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=os.path.join("confs/envs", ".env"), env_file_encoding="utf-8", extra="allow"
    )

    deploy_env: str = ""

    embed_model_path: str = "./models"

    forbidden_imports: str | None = None
    forbidden_keywords: str | None = None

    forbidden_imports_arr: list[str] = []
    forbidden_keywords_arr: list[str] = []


    llm_host: str = "https://ark.cn-beijing.volces.com"
    llm_path: str = "/api/v3/chat/completions"
    llm_model: str = ""
    llm_api_key: str = ""
 
    
    def __init__(self):
        super().__init__()

        if str_not_blank(self.forbidden_imports):
            self.forbidden_imports_arr = self.forbidden_imports.split(",")
            self.forbidden_imports_arr = [x.strip() for x in self.forbidden_imports_arr]
        
        if str_not_blank(self.forbidden_keywords):
            self.forbidden_keywords_arr = self.forbidden_keywords.split(",")
            self.forbidden_keywords_arr = [x.strip() for x in self.forbidden_keywords_arr]


        # if "uat" in self.deploy_env:
        #     tos_bucket_name = self.tos_bucket_name_uat
        #     llm_proxy = self.llm_proxy_uat
        #     callback_host = self.callback_host_uat
        # elif "prod" in self.deploy_env:
        #     tos_bucket_name = self.tos_bucket_name_prod
        #     llm_proxy = self.llm_proxy_prod
        #     callback_host = self.callback_host_prod
        # else:
        #     tos_bucket_name = self.tos_bucket_name
        #     llm_proxy = self.llm_proxy
        #     callback_host = self.callback_host

        # self.tos_bucket_name = tos_bucket_name
        # self.llm_proxy = llm_proxy
        # self.callback_host = callback_host
