import contextvars
import http
import logging
import logging.config
from logging.handlers import RotatingFileHandler
import os
from contextlib import asynccontextmanager
import sys
import threading
import time
import uuid
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from utils.tools import get_uuid, init_logging, resp_error
from routers import test_router, sandbox_router


request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id")

logger = logging.getLogger()
init_logging(request_id_var, logger)


# def init_env():
#     dotenv.load_dotenv()
#     logging.info("init env ok")


# 服务启动前初始化日志
@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        # init_env()
        # init_db()
        os.makedirs("output/sandbox", exist_ok=True)
    except Exception as e:
        logger.error(f"init_app error: {e}")

    logger.info("Starting server successfully ...")
    yield
    logger.info("Stopping server...")
    logger.info("Server stopped successfully ...")


# ng代理
root_path = ""
# root_path = "/tagserver"
app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, root_path=root_path)
app.include_router(test_router.router, prefix="/api/v1")
app.include_router(sandbox_router.router, prefix="/api/v1")


# http://localhost:8001/ui/run-code.html
app.mount("/ui", StaticFiles(directory="ui"))
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.middleware("http")
async def add_request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    token = request_id_var.set(request_id)

    try:
        response = await call_next(request)

        response.headers['X-Request-ID'] = request_id
        return response
    finally:
        request_id_var.reset(token)


@app.exception_handler(RequestValidationError)
async def request_validation_exception_handler(
    request: Request, e: RequestValidationError
):
    err_info = str(e)
    task_id = get_uuid()
    logging.error(
        f"request_validation_exception_handler task_id={task_id} err_info={err_info}"
    )
    first_error = e.errors()[0]

    return JSONResponse(
        status_code=http.HTTPStatus.OK,
        content=resp_error(first_error.get("msg", err_info), -1),
    )


@app.exception_handler(StarletteHTTPException)
async def starlette_http_exception_handler(request: Request, e: StarletteHTTPException):
    logger.error(f"starlette_http_exception_handler err_info={e.detail}")
    return JSONResponse(status_code=http.HTTPStatus.OK, content=resp_error(e.detail))


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, e: Exception):
    # e.with_traceback()

    return JSONResponse(
        status_code=http.HTTPStatus.INTERNAL_SERVER_ERROR, content={"message": str(e)}
    )


@app.get("/")
async def home():
    return {"message": "code_sandbox"}


@app.get("/health")
async def check_health():
    logger.info("health run ...")
    return {"message": "OK"}


@app.get("/env")
def env():
    env_name = os.environ.get("ENV_NAME", "default")
    logger.info("env run env_name=", env_name)

    return {
        "env_name": env_name,
    }


# FastAPI 中使用本地资源自定义 Swagger UI
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui():
    return get_swagger_ui_html(
        openapi_url="./openapi.json",  # 指定 OpenAPI 文档路径
        title="Sandbox API Docs",  # 自定义页面标题
        swagger_js_url="./static/swagger-ui/swagger-ui-bundle@5.js",  # 本地 JS 文件
        swagger_css_url="./static/swagger-ui/swagger-ui@5.css",  # 本地 CSS 文件
        swagger_favicon_url="./static/swagger-ui/favicon.png",  # 本地 favicon 图标
    )


@app.post("/restart")
async def restart_service():
    """
    返回成功后延迟重启
    """
    threading.Thread(target=_delayed_restart).start()
    return {"message": "Server will restart in 1 second"}


def _delayed_restart():
    time.sleep(1)
    logger.warning("Restarting server now...")
    python = sys.executable
    os.execl(python, python, *sys.argv)


# @app.get("/openapi")
# def openapi():
#     return app.openapi()


if __name__ == "__main__":
    import uvicorn

    # https://www.cnblogs.com/yoyoketang/p/17966998
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8019,
        # log_config="./confs/uvicorn_config_file.json",
    )
