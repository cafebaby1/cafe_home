from enum import Flag, auto


class Color(Flag):
    RED = auto()
    GREEN = auto()
    BLUE = auto()
    ALL = RED | GREEN | BLUE





def test_color():
    print(Color.RED.value)
    print(Color.GREEN in Color.ALL)



if __name__ == '__main__':
    test_color()