from typing import Any, Dict, Optional
import uuid
from pydantic import BaseModel, Field, field_validator


class RIDBaseModel(BaseModel):
    request_id: str = Field(
        default_factory=lambda: uuid.uuid4().hex,
        description="请求id",
    )

    def json_str(self) -> str:
        return self.model_dump_json(indent=4)


class RunCodeRequest(RIDBaseModel):
    content: str

    @field_validator("content")
    def validate_content(cls, v):
        if v is None or len(v.strip()) == 0:
            raise ValueError("content 不能为空")

        if len(v) > 5000:
            raise ValueError("content 长度不能超过5000字符")

        return v


class ExecuteCodeRequest(RIDBaseModel):

    code: str

    params: Optional[Dict[str, Any]] = Field(
        default=None,
        description="执行参数",
    )
    
    @field_validator("code")
    def validate_content(cls, v):
        if v is None or len(v.strip()) == 0:
            raise ValueError("code 不能为空")

        if len(v) > 10000:
            raise ValueError("code 长度不能超过5000字符")

        return v


class BuildContentVectorRequest(BaseModel):
    contents: list[dict[str, str]]
    content_key: str
    metadata_keys: list[str]

    @field_validator("contents")
    def validate_contents(cls, v):
        if v is None or len(v) == 0:
            raise ValueError("contents 不能为空")

        if len(v) > 3096:
            raise ValueError("contents 长度不能超过3096个对象")

        return v

    @field_validator("content_key")
    def validate_content_key(cls, v):
        if v is None or len(v.strip()) == 0:
            raise ValueError("content_key 不能为空")

        return v


class QueryContentVectorRequest(BaseModel):
    task_id: str
    question: str

    @field_validator("task_id")
    def validate_content_key(cls, v):
        if v is None or len(v.strip()) == 0:
            raise ValueError("task_id 不能为空")

        return v

    @field_validator("question")
    def validate_question(cls, v):
        if v is None or len(v.strip()) == 0:
            raise ValueError("question 不能为空")

        return v
