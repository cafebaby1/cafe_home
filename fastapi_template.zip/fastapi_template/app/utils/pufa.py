import asyncio
import json
import time
from typing import AsyncGenerator

from fastapi import Request


def sse_data(data: any):
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


class HeartBeatGenerator:
    def __init__(self, process_id: str, interval: float = 3.0):
        self.process_id = process_id
        self.interval = interval
        self.is_running = True

    async def generate_heartbeats(self) -> AsyncGenerator[dict, None]:
        while self.is_running:
            try:
                await asyncio.sleep(self.interval)

                if self.is_running:
                    data = {
                        "process_id": self.process_id,
                        "interval": self.interval,
                        "event_type": "heartbeat",
                        "message": "连接保持活跃",
                        "timestamp": time.time(),
                    }

                    yield data
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Heartbeat error: {e}")
                break

    def stop(self):
        self.is_running = False


class LongRunningProcessor:
    def __init__(self, process_id: str):
        self.process_id = process_id
        self.is_running = True
        self.heartbeat_generator = HeartBeatGenerator(process_id, interval=5.0)

    async def execute_task(self, request: Request) -> AsyncGenerator[str, None]:
        # start
        start_data = {
            "process_id": self.process_id,
            "interval": self.interval,
            "event_type": "start",
            "message": "连接保持活跃",
            "timestamp": time.time(),
        }

        yield sse_data(start_data)

        try:
            async for message in self._merge_generator(request):
                yield sse_data(message)
        finally:
            self.heartbeat_generator.stop()

    async def _merge_generator(self, request: Request) -> AsyncGenerator[dict, None]:
        # 创建队列来搜集所有信息
        message_queue = asyncio.Queue(maxsize=1000)

        heatbeat_task = asyncio.create_task(self._produce_heartbeat(message_queue))
        bussiness_task = asyncio.create_task(self._produce_business_data(message_queue))
        check_connection_task = asyncio.create_task(
            self._produce_check_connection(message_queue, request)
        )

        try:
            while self.is_running:
                try:
                    message = await asyncio.wait_for(message_queue.get(), timeout=2.0)
                    yield message

                    message_queue.task_done()
                except asyncio.TimeoutError:
                    if heatbeat_task.done() and bussiness_task.done():
                        break
                    continue
        except asyncio.CancelledError:
            print(f"_merge_generator 合并生成器被取消 {self.process_id}")
        finally:
            # 取消所有任务
            for task in [heatbeat_task, bussiness_task, check_connection_task]:
                if not task.done():
                    task.cancel()

            # 等待任务完成
            await asyncio.gather(
                heatbeat_task,
                bussiness_task,
                check_connection_task,
                return_exceptions=True,
            )

    async def _produce_heartbeat(self, queue: asyncio.Queue):
        try:
            async for message in self.heartbeat_generator.generate_heartbeats():
                if not self.is_running:
                    break

                await queue.put(message)
        except Exception as e:
            err_data = {
                "process_id": self.process_id,
                "event_type": "error",
                "message": str(e),
                "timestamp": time.time(),
            }

            await queue.put(err_data)

    async def _produce_business_data(self, queue: asyncio.Queue):
        try:
            async for message in self._bussiness_process():
                if not self.is_running:
                    break

                await queue.put(message)

                # 短暂休息
                await asyncio.sleep(0.2)
        except Exception as e:
            err_data = {
                "process_id": self.process_id,
                "event_type": "error",
                "message": f"业务逻辑处理错误 {str(e)}",
                "timestamp": time.time(),
                "status": "failed",
            }

            await queue.put(err_data)

    async def _bussiness_process(
        self, queue: asyncio.Queue
    ) -> AsyncGenerator[dict, None]:
        try:
            # 具体的业务逻辑处理
            steps = [{"name": "数据准备", "duration": 30, "desc": "加载和验证数据"}]

        except Exception as e:
            err_data = {
                "process_id": self.process_id,
                "event_type": "error",
                "message": f"业务逻辑处理错误 {str(e)}",
                "timestamp": time.time(),
                "status": "failed",
            }

            yield err_data

            raise

    async def _produce_check_connection(self, queue: asyncio.Queue, request: Request):
        while self.is_running:
            try:
                await asyncio.sleep(5)

                if await request.is_disconnected():
                    disconnected_data = {
                        "process_id": self.process_id,
                        "event_type": "error",
                        "message": "客户端断开链接",
                        "timestamp": time.time(),
                    }

                    await queue.put(disconnected_data)

                    self.stop()
                    break
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"_produce_check_connection 错误 {e}")
                break

    def stop(self):
        self.is_running = False
        self.heartbeat_generator.stop()
