import asyncio
from typing import Any, Callable, List, Tuple, Dict


async def async_batch_run(
    async_func: Callable[..., Any],
    task_args_list: List[Tuple[Tuple, Dict]],
    max_concurrency: int = 8,
) -> Tuple[List[Any], List[Dict[str, Any]]]:
    """
    【通用异步批量执行工具】
    支持任意异步函数 + 任意参数，自动控制并发、隔离异常、分类结果

    Args:
        async_func: 要批量执行的异步函数（任意业务逻辑）
        task_args_list: 任务参数列表，每个元素为 (位置参数元组, 关键字参数字典)
                        格式：[((arg1, arg2), {"kw1": val1}), ...]
        max_concurrency: 最大并发数限制

    Returns:
        ok_results: 成功结果列表（失败位为 None）
        error_list:  错误列表 [{"index": 任务索引, "error": 异常信息}, ...]
    """
    # 并发信号量
    semaphore = asyncio.Semaphore(max_concurrency)

    async def _safe_task_executor(index: int, args: tuple, kwargs: dict):
        print(f"_safe_task_executor index={index} args={args} kwargs={kwargs}")

        """安全执行单个异步任务，捕获所有异常"""
        try:
            async with semaphore:
                return await async_func(*args, **kwargs)
        except Exception as e:
            return Exception(f"任务[{index}]执行失败: {str(e)}")

    # 创建所有任务
    tasks = [
        _safe_task_executor(idx, args, kwargs)
        for idx, (args, kwargs) in enumerate(task_args_list)
    ]

    # 并发执行所有任务
    results = await asyncio.gather(*tasks)
    # 拆分成功/失败结果
    ok_results: List[Any] = []
    error_list: List[Dict[str, Any]] = []

    for idx, res in enumerate(results):
        if isinstance(res, Exception):
            error_list.append({"index": idx, "error": str(res)})
            ok_results.append(None)
        else:
            ok_results.append(res)

    return ok_results, error_list


class AsyncBatchExecutor:
    """【面向对象】通用异步批量执行器，支持复用并发配置"""

    def __init__(self, max_concurrency: int = 8):
        self.max_concurrency = max_concurrency
        self.semaphore = asyncio.Semaphore(max_concurrency)

    async def run(
        self, async_func: Callable[..., Any], task_args_list: List[Tuple[Tuple, Dict]]
    ) -> Tuple[List[Any], List[Dict[str, Any]]]:
        """执行批量异步任务"""

        async def _safe_task(idx, args, kwargs):
            try:
                async with self.semaphore:
                    return await async_func(*args, **kwargs)
            except Exception as e:
                return Exception(f"任务[{idx}]错误: {str(e)}")

        tasks = [_safe_task(i, *item) for i, item in enumerate(task_args_list)]

        # results = await asyncio.gather(*tasks)
        # 返回异常
        results = await asyncio.gather(*tasks, return_exceptions=True)

        ok_list, err_list = [], []
        for i, res in enumerate(results):
            if isinstance(res, Exception):
                err_list.append({"index": i, "error": str(res)})
                ok_list.append(None)
            else:
                ok_list.append(res)
        return ok_list, err_list


# ------------------------------
# 模拟你的业务异步函数（任意业务）
# ------------------------------
async def background_parser(
    session_id, input_str, result=None, date_result=None, date_str=""
):
    # 你的业务逻辑
    await asyncio.sleep(0.01)
    return f"完成-{session_id}"


# ------------------------------
# 1. 使用【通用函数】
# ------------------------------
async def test_use_function():
    # 构造任务参数：[(位置参数元组, 关键字参数字典), ...]
    jobs = [
        {"session_id": 1, "input": "test1", "date_str": "2025-01-01"},
        {"session_id": 2, "input": "test2", "date_str": "2025-01-01"},
    ]

    task_args = [
        (
            (
                job["session_id"],
                job["input"],
                job.get("result"),
                job.get("date_result"),
                job["date_str"],
            ),
            {},
        )
        for job in jobs
    ]
    print(f"task_args===={task_args}")

    # 直接调用通用工具
    ok, errors = await async_batch_run(
        async_func=background_parser, task_args_list=task_args, max_concurrency=2
    )
    print("函数版-成功结果:", ok)
    print("函数版-错误列表:", errors)


async def test_use_class():
    executor = AsyncBatchExecutor(max_concurrency=2)
    jobs = [{"session_id": 3, "input": "test3", "date_str": "2025-01-01"}]
    task_args = [((1, "test"), {}) for _ in jobs]
    ok, errors = await executor.run(background_parser, task_args)
    print("类版-成功结果:", ok)


if __name__ == "__main__":
    asyncio.run(test_use_function())
    # asyncio.run(test_use_class())
