import ast
import base64
import contextvars
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
import time
from typing import List
from urllib import parse
from urllib.parse import ParseResultBytes, urlparse
import uuid
from pathlib import Path
import zipfile
from multiprocessing import Value

import requests


def str_blank(contet: str) -> bool:
    if contet is None or contet.strip() == "":
        return True

    return False


def str_not_blank(contet: str) -> bool:
    return not str_blank(contet)


def resp_data(code: int, msg: str, data: any):
    return {
        "code": code,
        "msg": msg,
        "data": data,
    }


def resp_ok(data: any):
    return resp_data(0, "success", data)


def resp_error(msg: str, code: int = -1):
    return resp_data(code, msg, None)


def get_uuid() -> str:
    return str(uuid.uuid4().hex)


def json_stringify(data: any) -> str:
    return json.dumps(data, ensure_ascii=False)


def json2obj(data: any):
    return ast.literal_eval(data)


# 获取文件扩展名
def get_file_extension(url):
    parsed_url: ParseResultBytes = urlparse(url)

    if not all([parsed_url.scheme, parsed_url.netloc]):
        raise ValueError("Invalid URL")

    file_path = os.path.normpath(parsed_url.path)
    file_name = os.path.basename(file_path)

    file_extension = os.path.splitext(file_name)[1]
    return file_extension


def img_to_base64(img_path) -> str:
    with open(img_path, "rb") as f:
        img_bytes = base64.b64encode(f.read())
        imagestr = str(img_bytes)

        # 转成base64后的字符串格式为 b'图片base64字符串'，前面多了 b'，末尾多了 '，所以需要截取一下
        img_str = imagestr[2 : len(imagestr) - 1]
        return img_str


def get_file_path_from_url(url: str):
    parsed_url = urlparse(url)
    file_path = parsed_url.path.lstrip("/")

    return file_path


def get_current_timestamp():
    timestamp = int(time.time())

    return timestamp


# 压缩json数据
def json_compress(data: dict[str, any]) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def json_stringify(data: dict[str, any]) -> str:
    return json.dumps(data, ensure_ascii=False, indent=4)


def get_file_extension2(filename):
    return Path(filename).suffix[1:]


def parse_url(url: str):
    p = parse.urlparse(url)
    bucket = p.netloc.split(".")[0]
    key = p.path.lstrip("/")
    file_name = os.path.basename(key)
    file_ext = get_file_extension2(file_name)
    # file_path = os.path.join("tmp", file_name)
    base_name = os.path.splitext(file_name)[0]

    return bucket, key, file_name, file_ext, base_name


def download_file(url, local_filename):
    try:
        with requests.get(url, stream=True) as response:
            response.raise_for_status()

            # 打开本地文件以写入二进制数据
            with open(local_filename, "wb") as file:
                for chunk in response.iter_content(chunk_size=8192):
                    # 如果 chunk 不为 None，则写入文件
                    if chunk:
                        file.write(chunk)
    except Exception as e:
        e.with_traceback()
        raise RuntimeError(f"下载文件失败: {url}")


def format_timestamp(seconds):
    """
    格式化时间戳为字符串
    """
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    # milliseconds = int((seconds - int(seconds)) * 1000)
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"


def zip_folder(folder_path, output_zip_path):
    # 创建一个新的 ZIP 文件
    with zipfile.ZipFile(output_zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        # 遍历文件夹中的所有文件和子文件夹
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                # 获取文件的完整路径
                file_path = os.path.join(root, file)
                # 计算文件在 ZIP 文件中的相对路径
                arcname = os.path.relpath(file_path, folder_path)
                # 将文件添加到 ZIP 文件中
                zipf.write(file_path, arcname)


sep_line = "\n" + "-" * 60 + "\n"


def print_wrapper(arrs: List[str]):
    if arrs is None or len(arrs) == 0:
        raise Exception("arrs is null")

    arrs.insert(0, sep_line)
    arrs.append(sep_line)

    return "".join(arrs)


def md5(text: str):
    return hashlib.md5(text.encode("utf8")).hexdigest()


class AtomicInteger:
    """
    基于 multiprocessing.Value 实现的【多进程安全】原子整型类
    对标 Java AtomicInteger，提供原子操作方法
    """

    def __init__(self, initial: int = 0):
        """
        初始化原子整数
        :param initial: 初始值，默认 0
        """
        # 'i' = 有符号整型 (int)；默认自带进程锁，保证操作原子性
        self._shared_value: Value = Value("i", initial)

    def get(self) -> int:
        """原子获取当前值"""
        with self._shared_value:  # 自动加锁/解锁，保证读取原子性
            return self._shared_value.value

    def set(self, value: int) -> None:
        """原子设置值"""
        with self._shared_value:
            self._shared_value.value = value

    def add(self, delta: int) -> int:
        """
        原子增加指定数值
        :param delta: 增量（正数=加，负数=减）
        :return: 增加后的新值
        """
        with self._shared_value:
            self._shared_value.value += delta
            return self._shared_value.value

    def increment(self) -> int:
        """原子自增 1（返回新值）"""
        return self.add(1)

    def decrement(self) -> int:
        """原子自减 1（返回新值）"""
        return self.add(-1)

    def compare_and_set(self, expect: int, update: int) -> bool:
        """
        原子 CAS (Compare And Set) 核心操作
        :param expect: 预期当前值
        :param update: 要设置的新值
        :return: 成功返回 True，失败返回 False
        """
        with self._shared_value:
            if self._shared_value.value == expect:
                self._shared_value.value = update
                return True
            return False

    def __repr__(self) -> str:
        return f"AtomicInteger(value={self.get()})"


def init_logging(contextVar: contextvars.ContextVar, logger: logging.Logger) -> logging.Logger:
    class RequestIDFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            record.request_id = contextVar.get("N/A")

            return True

    # log_format = "%(asctime)s - %(module)s - %(funcName)s - line:%(lineno)d - %(levelname)s - %(message)s"
    log_format = "%(asctime)s - [%(request_id)s] - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    # logger = logging.getLogger()
    logger.handlers.clear()
    logger.setLevel(logging.INFO)
   
    file_handler = RotatingFileHandler(
        filename="app.log",
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter(log_format, date_format))


    logger.addFilter(RequestIDFilter())
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(log_format, date_format))

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    # logging.getLogger("uvicorn").setLevel(logging.WARNING)
    # logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

    print('11111')

    return logger

