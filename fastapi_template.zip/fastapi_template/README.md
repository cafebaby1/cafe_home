

## fastapi-temp

> https://github.com/tonyljx/chunxiang-fastapi-temp

> https://mp.weixin.qq.com/s/V1TWieKjIwN2-82ClVlfmg



## Run

> https://bookish-goldfish-7779pgxj6w4hxw44.github.dev/?folder=%2Fworkspaces%2Fcode_sandbox

> https://fluffy-telegram-4qq7wxrp4rjf7r9g.github.dev/




```sh

conda create --name echo_fastapi python=3.10  -y
conda create --name echo_fastapi -c conda-forge python=3.10  -y

conda activate echo_fastapi

pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple


curl -fsSL https://deno.land/install.sh | sh


cp .env.example ./app/confs/envs/.env

conda activate echo_fastapi && cd app

uvicorn main:app --host 0.0.0.0 --port 8001 --log-config ./confs/uvicorn_config.json



pip install modelscope==1.18.0 -i https://mirrors.aliyun.com/pypi/simple

pip install llama-index-embeddings-huggingface==0.3.1 -i https://mirrors.aliyun.com/pypi/simple




source  /workspace/video_summary/echo_venv/bin/activate
pip install modelscope==1.18.0

```









```


var a = `import pandas as pd
 
# 创建一个简单的 DataFrame
data = {'Name': ['John', 'Alice', 'Bob'], 'Age': [25, 30, 35]}
df = pd.DataFrame(data)
 
# 打印 DataFrame
print(df)
 
# 计算平均年龄
average_age = df['Age'].mean()
print(f"The average age is {average_age}.")
`


var a = `
def sum(a, b):
    return (a + b)

a = int(input('Enter 1st number: '))
b = int(input('Enter 2nd number: '))

print(f'Sum of {a} and {b} is {sum(a, b)}')
`



var a = `
print('Hello,world!')
for i in range(10):
    print(i)
    # eval(1+1)
    # print 1+'1'
    
# import os
# import importlib
# module_name = "os"
# math_module = importlib.import_module(module_name
# print(math_module.getcwd())
`



var a = `
# Python 3.10 在线环境
# 此代码将发送至远程服务器执行

import sys

print("Python 运行时已启动")


# 列表推导式
squares = [x**2 for x in range(5)]
print(f"前5个数字的平方: {squares}")
`

var b = {"content": a}

console.log(JSON.stringify(b))



var a = `
def test_code(input_data):
    print(f"echo===={input_data['a']}")
`

var b = {"code": a, "params": {"input_data": {"a": "None"}}}
console.log(JSON.stringify(b))


var a = `
def bad_code():
    print('malicious')
`

var b = {"code": a, "params": {}}
console.log(JSON.stringify(b))



var a = `
import time
from math import sqrt, pi

def calculate(x):
    time.sleep(2)
    return {
        'value': x,
        'sqrt': sqrt(x),
        'pi_times_x': pi * x
    }
`
var b = {"code": a, "params": {"x": 5}}
console.log(JSON.stringify(b))




var a = `
def test():
    i = 0
    while i < 10:
        print(i)
        if i == 5:  # 无法静态分析
            break
        i += 1
`
var b = {"code": a, "params": {}}
console.log(JSON.stringify(b))



死循环

{"code":"\ndef test():\n    for i in range(99999999999999999999):\n        pass\n","params":{}}

{"code":"\ndef test():\n    while 1:\n        print(\"loop\")\n","params":{}}

{"code":"\ndef test():\n    while True:\n        print('11')\n","params":{}}


{"code":"\ndef test():\n    i = 0\n    while i < 10:\n        print(i)\n        if i == 5:  # 无法静态分析\n            break\n        i += 1\n","params":{}}


{"code":"\ndef bad_code():\n    print('malicious')\n","params":{}}


{
    "code": "\nfrom math import sqrt, pi\n\ndef calculate(x):\n    return {\n        'value': x,\n        'sqrt': sqrt(x),\n        'pi_times_x': pi * x\n    }\n",
    "params": {
        "x": 5
    }
}



error

{
    "code": "\nfrom math import sqrt1, pi\n\ndef calculate(x):\n    return {\n        'value': x,\n        'sqrt': sqrt(x),\n        'pi_times_x': pi * x\n    }\n",
    "params": {
        "x": 5
    }
}


超时

{"code":"\nimport time\nfrom math import sqrt, pi\n\ndef calculate(x):\n    time.sleep(2)\n    return {\n        'value': x,\n        'sqrt': sqrt(x),\n        'pi_times_x': pi * x\n    }\n","params":{"x":5}}






{"code":"import socket\n\ndef test():\n    s = socket.socket()\n    s.settimeout(1)\n    s.connect((\"127.0.0.1\", 8019))\n    return \"connected\"","params":{}}




```





## 日志
> https://chatgpt.com/c/698c138a-e210-8321-b475-c1e96c20b7e4
> https://www.cnblogs.com/XY-Heruo/p/17981378
> https://www.cnblogs.com/ymtianyu/p/19546427





```py

pip install confluent-kafka



import json
import logging
import socket
import traceback
from datetime import datetime
from confluent_kafka import Producer


class KafkaLoggingHandler(logging.Handler):
    def __init__(
        self,
        *,
        brokers: str,
        topic: str,
        client_id: str = "python-logger",
        acks: str = "1",
        linger_ms: int = 50,
        batch_size: int = 16384,
        enable_idempotence: bool = False,
        extra_producer_config: dict | None = None,
    ):
        super().__init__()

        conf = {
            "bootstrap.servers": brokers,
            "client.id": client_id,
            "acks": acks,
            "linger.ms": linger_ms,
            "batch.size": batch_size,
            "enable.idempotence": enable_idempotence,
        }

        if extra_producer_config:
            conf.update(extra_producer_config)

        self.topic = topic
        self.hostname = socket.gethostname()
        self.producer = Producer(conf)

    def emit(self, record: logging.LogRecord):
        try:
            payload = self._format_record(record)

            self.producer.produce(
                topic=self.topic,
                value=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                key=record.name,
                on_delivery=self._delivery_report,
            )

            # 非阻塞轮询（触发回调）
            self.producer.poll(0)

        except Exception:
            self.handleError(record)

    def _format_record(self, record: logging.LogRecord) -> dict:
        data = {
            "timestamp": datetime.utcfromtimestamp(record.created).isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "file": record.pathname,
            "line": record.lineno,
            "function": record.funcName,
            "process": record.process,
            "thread": record.threadName,
            "host": self.hostname,
        }

        if record.exc_info:
            data["exception"] = "".join(traceback.format_exception(*record.exc_info))

        return data

    @staticmethod
    def _delivery_report(err, msg):
        if err:
            # ⚠️ 生产环境可打到 stderr 或 fallback 文件
            print(f"[KafkaLogError] {err} -> {msg.topic()}")

    def close(self):
        self.producer.flush(timeout=5)
        super().close()




=========================================================
快速接入 logging（最小示例）
import logging

logger = logging.getLogger("app")
logger.setLevel(logging.INFO)

kafka_handler = KafkaLoggingHandler(
    brokers="localhost:9092",
    topic="python-logs",
    client_id="my-service",
)

logger.addHandler(kafka_handler)

logger.info("service started")
logger.error("something failed", exc_info=True)







=========================================================
生产级 logging 配置（推荐）
logging.config.dictConfig
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "kafka": {
            "()": "your_module.KafkaLoggingHandler",
            "brokers": "kafka01:9092,kafka02:9092",
            "topic": "python-logs",
            "client_id": "order-service",
            "acks": "all",
            "linger_ms": 100,
        }
    },
    "root": {
        "level": "INFO",
        "handlers": ["kafka"],
    },
}

import logging.config
logging.config.dictConfig(LOGGING_CONFIG)

```







```

pip install kafka-logging-handler==0.2.5


import logging
from kafka_logger.handlers import KafkaLoggingHandler

KAFKA_BOOTSTRAP_SERVER = ('<hostname:port>')
KAFKA_CA = '<path_to_ca_cert>'
TOPIC = '<publish_topic>'

logger = logging.getLogger('MyCoolProject')

# Instantiate your kafka logging handler object
kafka_handler_obj = KafkaLoggingHandler(KAFKA_BOOTSTRAP_SERVER,
                                        TOPIC,
                                        ssl_cafile=KAFKA_CA)

logger.addHandler(kafka_handler_obj)
# Set logging level
logger.setLevel(logging.DEBUG)

logger.info('Happy Logging!')
Troubleshooting
If you see the following error when running on macOS:

Traceback (most recent call last):
  File "/path/to/kafka-logging-handler/kafka_logger/handlers.py", line 109, in __init__
    'host_ip': socket.gethostbyname(socket.gethostname())
socket.gaierror: [Errno 8] nodename nor servname provided, or not known
The issues is that socket.gethostname() resolves to a name that is not available in /etc/hosts. First run python3 -c "import socket; print(socket.gethostname())" to get the name (e.g. MacBook-Pro). Then fix it with sudo echo 127.0.0.1 MacBook-Pro >> /etc/hosts, where MacBook-Pro is your computer name. There won't be OS-specific fix for it in the library.


```





> https://stackoverflow.com/questions/21102293/how-to-write-to-kafka-from-python-logging-module

```py

# Source - https://stackoverflow.com/a/21122445
# Posted by Wildfire
# Retrieved 2026-02-11, License - CC BY-SA 3.0

from kafka.client import KafkaClient
from kafka.producer import SimpleProducer,KeyedProducer
import logging,sys

class KafkaLoggingHandler(logging.Handler):

    def __init__(self, host, port, topic, key=None):
        logging.Handler.__init__(self)
        self.kafka_client = KafkaClient(host, port)
        self.key = key
        if key is None:
            self.producer = SimpleProducer(self.kafka_client, topic)
        else:
            self.producer = KeyedProducer(self.kafka_client, topic)

    def emit(self, record):
        #drop kafka logging to avoid infinite recursion
        if record.name == 'kafka':
            return
        try:
            #use default formatting
            msg = self.format(record)
            #produce message
            if self.key is None:
                self.producer.send_messages(msg)
            else:
                self.producer.send(self.key, msg)
        except:
            import traceback
            ei = sys.exc_info()
            traceback.print_exception(ei[0], ei[1], ei[2], None, sys.stderr)
            del ei

    def close(self):
        self.producer.stop()
        logging.Handler.close(self)

kh = KafkaLoggingHandler("localhost", 9092, "test_log")
#OR
#kh = KafkaLoggingHandler("localhost", 9092, "test_log", "key1")

logger = logging.getLogger("")
logger.setLevel(logging.DEBUG)
logger.addHandler(kh)
logger.info("The %s boxing wizards jump %s", 5, "quickly")
logger.debug("The quick brown %s jumps over the lazy %s", "fox",  "dog")
try:
    import math
    math.exp(1000)
except:
    logger.exception("Problem with %s", "math.exp")




# The handler uses this Kafka client: https://github.com/mumrah/kafka-python

```


### 2

```py

# Source - https://stackoverflow.com/a/50489652
# Posted by sebito91, modified by community. See post 'Timeline' for change history
# Retrieved 2026-02-11, License - CC BY-SA 4.0

# -*- coding: utf-8 -*-
"""Module to test out logging to kafka."""

import json
import logging

from utils.kafka_handler import KafkaHandler
from kafka import KafkaProducer


def run_it(logger=None):
    """Run the actual connections."""

    logger = logging.getLogger(__name__)
    # enable the debug logger if you want to see ALL of the lines
    #logging.basicConfig(level=logging.DEBUG)
    logger.setLevel(logging.DEBUG)

    kh = KafkaHandler(['localhost:9092'], 'sebtest')
    logger.addHandler(kh)

    logger.info("I'm a little logger, short and stout")
    logger.debug("Don't tase me bro!")


if __name__ == "__main__":
    run_it()




# Source - https://stackoverflow.com/a/50489652
# Posted by sebito91, modified by community. See post 'Timeline' for change history
# Retrieved 2026-02-11, License - CC BY-SA 4.0

# -*- coding: utf-8 -*-
"""Module to provide kafka handlers for internal logging facility."""

import json
import logging
import sys

from kafka import KafkaProducer


class KafkaHandler(logging.Handler):
    """Class to instantiate the kafka logging facility."""

    def __init__(self, hostlist, topic='corp_it_testing', tls=None):
        """Initialize an instance of the kafka handler."""
        logging.Handler.__init__(self)
        self.producer = KafkaProducer(bootstrap_servers=hostlist,
                                      value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                                      linger_ms=10)
        self.topic = topic

    def emit(self, record):
        """Emit the provided record to the kafka_client producer."""
        # drop kafka logging to avoid infinite recursion
        if 'kafka.' in record.name:
            return

        try:
            # apply the logger formatter
            msg = self.format(record)
            self.producer.send(self.topic, {'message': msg})
            self.flush(timeout=1.0)
        except Exception:
            logging.Handler.handleError(self, record)

    def flush(self, timeout=None):
        """Flush the objects."""
        self.producer.flush(timeout=timeout)

    def close(self):
        """Close the producer and clean up."""
        self.acquire()
        try:
            if self.producer:
                self.producer.close()

            logging.Handler.close(self)
        finally:
            self.release()

```







### AI


#### 代码在线运行网站

```

使用html+js+tailwindcss，帮我制作代码在线运行的网站。

1. 左侧是代码区域，右侧是运行结果区域。点击运行按钮，代码会被发送到服务器，服务器会执行代码，并将结果返回给前端。
2. 代码区域支持多种编程语言，包括JS、Python
3. 响应式布局支持手机端和PC端。


```




#### on

```

使用html+js+tailwindcss，帮我制作代码在线运行的网站。

1. 左侧是代码区域，右侧是运行结果区域。点击运行按钮，代码会被发送到服务器，服务器会执行代码，并将结果返回给前端。
2. 代码区域支持多种编程语言，包括JS、Python
3. 响应式布局支持手机端和PC端。
4. 网页整体采用科技风格


你是资深全栈架构师，帮助我开发一个学生管理系统。采用前后端分离架构，要求生成完整结构化代码，并包含详细说明。
技术栈要求：
    - 前端：Next.js（App Router，TypeScript），UI 使用 Ant Design 或 Chakra UI- 状态管理：React Query / Zustand（二选一）
    - 后端：Python（FastAPI 或 Flask）- 数据库：MySQL（SQLAlchemy + Alembic 管理迁移）
    - API 风格：RESTful
    - 认证：JWT 登录认证
    - Docker：前后端及 MySQL 提供 docker-compose 部署

功能模块要求：
1. 学生信息管理模块- 学生基本信息增删改查：姓名、性别、学号、身份证、联系电话、照片- 学籍状态：在读/休学/毕业- 支持搜索、分页、导出
2. 班级与院系管理模块- 学院、专业、班级维护- 学生与班级关联- 班主任信息记录
3. 课程与教学管理模块- 课程 CRUD，课程编号、学时、学分- 教师信息维护- 学生选课（至少一个课程可以配多个学生）- 成绩记录表，支持录入/修改/查询

API 示例
- GET /students?page=1&keyword=xxx
- POST /students
- PUT /students/{id}
- DELETE /students/{id}

性能与结构要求：
- 前端：页面按模块划分，表格+表单为主界面
- 后端：模块化结构，清晰的 controller / service / model 
- 提供 ER 图、接口文档和数据库建表 SQL
- 提供 README 和使用说明
- 所有代码可直接运行

项目根目录结构建议：
- frontend
- backend
- docker-compose.yml

请一次性输出完整可运行项目代码。允许分步输出，但结构必须完整清晰。

```









### 爆款文案
> https://www.coze.cn/open/playground/workflow_stream_run
> https://www.coze.cn/work_flow?workflow_id=7579245209839288339&space_id=7330585923886891045

```


选题制造机


行业/领域/产品：

婚礼跟拍
人设IP打造教学



选题类型：

排雷选题
猎奇窥探
二元对立
排雷选题
慕强崇拜
荷尔蒙吸引力
框定人群
成本选题
身份认同
性张力
颠覆反差


选题生成




1. 南方婚礼跟拍VS北方婚礼跟拍,镜头里的热闹根本不是
2. 新人想要的"电影感"VS长辈想要的"全家福",婚礼跟拍师



行业：婚礼跟拍
选题类型：二元对立

选题生成：
1. 千元婚礼跟拍VS万元婚礼跟拍,差的仅仅是价格吗?
2. 十年前的婚礼跟拍VS现在的婚礼跟拍,新娘看了都想重结
3. 婚礼跟拍师拍新娘VS拍新郎,镜头里的偏爱也太明显了吧
4. 外行眼中的婚礼跟拍VS内行眼中的婚礼跟拍,这水到底有多深
5. 婚礼跟拍师理想中的拍摄VS现实中的拍摄,大型"翻车"现场






# 你是一名顶尖的选题内容策略专家
擅长将抽象的选题类型转化为具体、可执行、能引爆流量的内容选题。请根据用户提供的 行业/领域/产品 和 选题类型，生成符合该类型核心逻辑的、具有高传播潜力的具体选题。


## 你的思考与生成步骤：
解析组合：理解“行业”与“选题类型”的内在联系，找到最能激发目标用户情绪或需求的结合点。
生成输出：输出5条选题


## 例子：
用户输入：
行业：婚礼跟拍
选题类型：二元对立

输出：
1. 千元婚礼跟拍VS万元婚礼跟拍,差的仅仅是价格吗?
2. 十年前的婚礼跟拍VS现在的婚礼跟拍,新娘看了都想重结
3. 婚礼跟拍师拍新娘VS拍新郎,镜头里的偏爱也太明显了吧
4. 外行眼中的婚礼跟拍VS内行眼中的婚礼跟拍,这水到底有多深
5. 婚礼跟拍师理想中的拍摄VS现实中的拍摄,大型"翻车"现场



curl -X POST 'https://api.coze.cn/v1/workflow/run' \
-H "Authorization: Bearer cztei_lrZRsCPrHM7gSxZqOaYk35lBJ7U3Q7lbx4A8PYd655fWpQu1G6Jtyu3OqN2ZRRAjs" \
-H "Content-Type: application/json" \
-d '{
  "workflow_id": "7579245209839288339",
  "parameters": {
    "hangye": "小红书营销",
    "xt_type": "二元对立"
  }
}'


{"msg":"","data":"{\"content_type\":1,\"data\":\"1. 新手做小红书VS老手做小红书，差距真的只是经验吗？  \\n2. 小红书免费流量VS付费投流，哪个更适合刚起步的账号？  \\n3. 小红书先做内容质量VS先追流量数据，谁才是长期涨粉的关键？  \\n4. 小红书真实分享人设VS包装完美人设，哪种账号更能留住粉丝？  \\n5. 小红书个人号运营VS企业号运营，逻辑居然差这么多？  \\n\\n每个选题都聚焦小红书营销的核心冲突点，用强烈对比引发好奇，精准戳中新手、中小博主及企业运营者的决策痛点，具备高传播潜力。\",\"original_result\":null,\"type_for_model\":2}","debug_url":"https://www.coze.cn/work_flow?execute_id=7579247875521151019&space_id=7330585923886891045&workflow_id=7579245209839288339&execute_mode=2","usage":{"token_count":949,"output_count":654,"input_count":295},"execute_id":"7579247875521151019","detail":{"logid":"20251202211242EEC77AB51A7AFFCBCED1"},"code":0}





选题生成
开场钩子




短视频文案
人设故事：

其他要求：

类型：强观点、讲观点、说知识、讲故事

选题：

开场钩子：
外贸老板最怕的一句话:
'这单我找别家做了,价
格比你低30%!

文案：

儿朴前年的增值税就掏了40万...
【版本一:痛点解决模型(利器一)】
(镜头拉近,萍姐对着镜头比划)
"做外贸的老板们,是不是一听客户说'别家比你低30%,魂儿
都吓飞了?(突然拍桌子)我跟你说8年前我第一次听到这话,
当场把计算器按冒火星子!"
(转身指向仓库)
"现在?教你三招接住这招降维打击:第一招,掏样品!把咱2万
平工厂做的加厚款摔地上,您听这声儿,他那价能给这料?'第
二招,翻聊天记录!王总您去年那批货,海关查验我通宵盯着
没加钱吧?'第三招最狠..."(突然压低声音)"偷偷告诉他'其实
我也能做那价,就是得用回收料,您敢要吗?"(捂嘴笑)






```
